puts 100
puts 100 + 3  # 足し算
puts 100 - 3  # 引き算
puts 100 * 3  # 掛け算
puts 100 / 3  # 割り算
puts 100 % 3  # 割り算の余り