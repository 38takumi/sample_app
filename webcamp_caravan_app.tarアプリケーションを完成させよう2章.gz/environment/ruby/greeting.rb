def greeting(name)
#   "Hello, #{name}!"  # この行のnameは、引数で渡すname
return "Hello, #{name}!"
   "Good morning, #{name}!"
end

puts greeting('John')  # 'John'を引数として渡す