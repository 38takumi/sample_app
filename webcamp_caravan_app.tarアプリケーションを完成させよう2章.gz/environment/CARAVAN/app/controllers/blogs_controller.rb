class BlogsController < ApplicationController
  def index
  end

  def show
  end

  def new
  end

  def edit
  end
end
