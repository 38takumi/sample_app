# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'f293f80ddc7081f7359c07b5a7a76b31a14988e052fd37ebec90a5b5447a83527d91a31abf11c3f04b79e6455d2384a5b3c2a969a7a218c75ae5330f5da9698f'