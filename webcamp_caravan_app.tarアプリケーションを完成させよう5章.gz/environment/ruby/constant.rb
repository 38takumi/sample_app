Pi = 3.14
puts Pi

Pi = 100  # この行を追加
puts Pi  # この行を追加