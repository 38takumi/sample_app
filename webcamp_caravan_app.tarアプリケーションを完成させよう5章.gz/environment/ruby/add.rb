for i in 1..6 do  # "1..6"は、1～6までの範囲を表す
  puts i
end