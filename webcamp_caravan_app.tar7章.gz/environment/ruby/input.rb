puts "キーボードから何か入力してみましょう"
input_key = gets
puts "入力された内容は#{input_key}"