total = 100
if total < 200
  puts "合計は200未満です"
end

if total >= 150  # この行を追加
  puts "合計は150以上です"  # この行を追加
end  # この行を追加