name = "A"
weight = 50

puts name + "さんの体重は" + weight.to_s + "kgです"  # この行を追加
puts "#{name}さんの体重は#{weight}kgです"  # この行を追加
puts '#{name}さんの体重は#{weight}kgです'  # この行を追加